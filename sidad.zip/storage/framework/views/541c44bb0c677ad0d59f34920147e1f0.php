<form action="/karyawan/<?php echo e($karyawan->nik); ?>/update" method="POST" id="frmKaryawan" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div>
        <div class="mb-3">
            <input type="hidden" class="form-control" id="nik" name="nik" placeholder="Masukan Nik"
                value="<?php echo e($karyawan->nik); ?>">
        </div>
        <div class="mb-3">
            <label for="addcontact-name-input" class="form-label">Nama</label>
            <input type="text" class="form-control" id="nama_lenkap" name="nama_lenkap" placeholder="Nama Lengkap"
                value="<?php echo e($karyawan->nama_lenkap); ?>">
        </div>
        <div class="mb-3">
            <label for="addcontact-designation-input" class="form-label">Alamat</label>
            <input type="text" class="form-control" id="jabatan" name="jabatan" placeholder="Jabatan"
                value="<?php echo e($karyawan->jabatan); ?>">
        </div>
        <div class="mb-3">
            <label for="addcontact-designation-input" class="form-label">No HP</label>
            <input type="text" class="form-control" id="no_hp" name="no_hp" placeholder="No HP"
                value="<?php echo e($karyawan->no_hp); ?>">
        </div>


        <div class="mb-3">
            <label class="col-md-2 col-form-label">Kecamatan</label>
            <select name="kode_dept" id="kode_dept" class="form-select">
                <option value=""> Kecamatan </option>
                <?php $__currentLoopData = $departemen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($karyawan->kode_dept == $d->kode_dept ? 'selected' : ''); ?> value="<?php echo e($d->kode_dept); ?>">
                        <?php echo e($d->nama_dept); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

        </div>

        <div class="mb-3">
            <label class="col-md-2 col-form-label">Desa</label>
            <select name="kode_cabang" id="kode_cabang" class="form-select">
                <option value=""> Desa </option>
                <?php $__currentLoopData = $cabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($karyawan->kode_cabang == $d->kode_cabang ? 'selected' : ''); ?>

                        value="<?php echo e($d->kode_cabang); ?>">
                        <?php echo e($d->nama_cabang); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

        </div>


        <div class="mb-3">
            <label for="addcontact-file-input" class="form-label">Foto</label>
            <input type="file" class="form-control" id="foto" name="foto">
            <input type="hidden" name="old_foto" value="<?php echo e($karyawan->foto); ?>">
        </div>
        <div class="mb-3">
            <form-group>
                <button class="btn btn-success w-100"><i class="fa fa-upload"> Update</i></button>
            </form-group>
        </div>
    </div>
</form>
<?php /**PATH D:\SIDAD\sidad\resources\views/karyawan/edit.blade.php ENDPATH**/ ?>