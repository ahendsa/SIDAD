<?php $__currentLoopData = $histori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <ul class="listview image-listview">
        <?php
            $path = Storage::url('uploads/absensi/' . $d->foto_in);
        ?>

        <li>
            <div class="item">
                <img src="<?php echo e(url($path)); ?>" alt="image" class="image">
                <div class="in">
                    <div><?php echo e(date('d-m-Y', strtotime($d->tgl_presensi))); ?>

                        <br>

                    </div>
                    <span class="badge bg-primary <?php echo e($d->jam_in < '07:00' ? 'bg-success' : 'bg-danger'); ?>">
                        <?php echo e($d->jam_in); ?>

                    </span>
                    <span class="badge bg-danger"><?php echo e($d->jam_out); ?></span>

                </div>
            </div>
        </li>
    </ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\SIDAD\sidad\resources\views/presensi/gethistori.blade.php ENDPATH**/ ?>