<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <title>Vertical | Vuesy - Admin & Dashboard Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesdesign" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('admin/images/favicon.ico')); ?>">
    <!-- plugin css -->
    <!-- Sweet Alert-->
    <link href="<?php echo e(asset('admin/libs/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Bootstrap Css -->
    <link href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>" id="bootstrap-style" rel="stylesheet" type="text/css">
    <!-- Icons Css -->
    <link href="<?php echo e(asset('admin/css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
    <!-- App Css-->
    <link href="<?php echo e(asset('admin/css/app.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css">




</head>

<body data-topbar="dark" data-sidebar="dark" data-layout-mode="dark">

    <!-- Begin page -->
    <div id="layout-wrapper">
        <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!-- ========== Left Sidebar Start ========== -->
        <?php echo $__env->make('admin.layouts.leftsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Left Sidebar End -->

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">
            <?php echo $__env->yieldContent('content'); ?>

            <!-- container-fluid -->
        </div>
        <!-- End Page-content -->


    </div>
    <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->

    <!-- Right Sidebar -->

    <!-- /Right-bar -->

    <!-- Right bar overlay-->

    <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- JAVASCRIPT -->
    <!modal--->
        //


        <!-- JAVASCRIPT -->
        <script src="<?php echo e(asset('admin/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/libs/metismenujs/metismenujs.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/libs/simplebar/simplebar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/libs/feather-icons/feather.min.js')); ?>"></script>

        <!-- Sweet Alerts js -->
        <script src="<?php echo e(asset('admin/libs/sweetalert2/sweetalert2.min.js')); ?>"></script>

        <!-- Sweet alert init js-->
        <script src="<?php echo e(asset('admin/js/pages/sweet-alerts.init.js')); ?>assets/js/pages/sweet-alerts.init.js"></script>

        <script src="<?php echo e(asset('admin/js/app.js')); ?>"></script>
        <?php echo $__env->yieldPushContent('myscript'); ?>



</body>

</html>
<?php /**PATH D:\SIDAD\sidad\resources\views/admin/layouts/index.blade.php ENDPATH**/ ?>