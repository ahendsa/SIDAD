
<?php /**PATH D:\SIDAD\sidad\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>