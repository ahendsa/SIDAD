<!--**********************************
    Footer start
***********************************-->
<div class="footer">
    <div class="copyright">
        <p>Copyright © Designed &amp; Developed by <a href="https://dexignlab.com/" target="_blank">DexignLab</a> 2022</p>
    </div>
</div>
<!--**********************************
    Footer end
***********************************-->
<?php /**PATH D:\SIDAD\sidad\resources\views/dashboard/admin/layouts/footer.blade.php ENDPATH**/ ?>